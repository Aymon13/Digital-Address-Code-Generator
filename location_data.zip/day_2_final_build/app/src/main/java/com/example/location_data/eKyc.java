package com.example.location_data;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class eKyc extends AppCompatActivity {
    TextView login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_ekyc);
        Button b = findViewById(R.id.link);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(eKyc.this, "KYC added", Toast.LENGTH_LONG).show();
                //Intent intent0 = new Intent(getApplicationContext(),profile.class);
               // startActivity(intent0);
            }
        });

    }
}